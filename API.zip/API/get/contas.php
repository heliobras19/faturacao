<?php

class contas
{
    public function __construct()
    {
        $var = ['helio', 'tomas'];
        echo json_encode($var);
    }
}