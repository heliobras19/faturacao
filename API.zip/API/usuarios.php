<?php

class usuario
{
}