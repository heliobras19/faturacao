<?php

include "autoload.php";
$start = new Core();